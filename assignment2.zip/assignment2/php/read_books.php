<?php
include 'db.php'; // Adjust path if necessary

$sql = "SELECT books.book_id, books.title, authors.author_name AS author, books.genre, books.published_year, books.image 
        FROM books 
        JOIN authors ON books.author_id = authors.author_id";
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {
    echo "<table><tr><th>Book ID</th><th>Title</th><th>Author</th><th>Genre</th><th>Published Year</th><th>Image</th><th>Actions</th></tr>";
    while($row = mysqli_fetch_assoc($result)) {
        echo "<tr><td>{$row['book_id']}</td><td>{$row['title']}</td><td>{$row['author']}</td><td>{$row['genre']}</td><td>{$row['published_year']}</td>
              <td><img src='images/{$row['image']}' alt='{$row['title']}' width='50'></td>
              <td><a href='update_book.php?id={$row['book_id']}'>Edit</a> | <a href='delete_book.php?id={$row['book_id']}'>Delete</a></td></tr>";
    }
    echo "</table>";
} else {
    echo "0 results";
}

mysqli_close($conn); // Close the connection here
?>
