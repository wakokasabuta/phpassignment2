<?php
include 'db.php';

$full_name = $_POST['full_name'];
$phone_number = $_POST['phone_number'];

$sql = "INSERT INTO users (full_name, phone_number) VALUES ('$full_name', '$phone_number')";
if (mysqli_query($conn, $sql)) {
    echo "New user created successfully";
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}

mysqli_close($conn);
header('Location: user.php');
?>
