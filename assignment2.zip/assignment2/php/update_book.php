<?php
include 'db.php';

// Check if form is submitted
if (isset($_POST['update'])) {
    $book_id = $_POST['book_id'];
    $title = $_POST['title'];
    $author = $_POST['author'];
    $genre = $_POST['genre'];
    $published_year = $_POST['published_year'];

    // Update query
    $query = "UPDATE books SET title='$title', author='$author', genre='$genre', published_year='$published_year' WHERE book_id=$book_id";

    if (mysqli_query($conn, $query)) {
        echo "Record updated successfully";
    } else {
        echo "Error updating record: " . mysqli_error($conn);
    }
}

// Check if book ID is provided in the URL
if (isset($_GET['id'])) {
    $book_id = $_GET['id'];

    // Fetch book details
    $query = "SELECT * FROM books WHERE book_id=$book_id";
    $result = mysqli_query($conn, $query);

    if (mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);
        $title = $row['title'];
        $author = $row['author'];
        $genre = $row['genre'];
        $published_year = $row['published_year'];
    } else {
        echo "No book found with the given ID.";
    }
} else {
    echo "No book ID provided.";
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Update Book</title>
</head>
<body>
    <h2>Update Book</h2>
    <form method="post" action="update_book.php">
        <input type="hidden" name="book_id" value="<?php echo $book_id; ?>">
        <label>Title:</label><br>
        <input type="text" name="title" value="<?php echo htmlspecialchars($title); ?>"><br>
        <label>Author:</label><br>
        <input type="text" name="author" value="<?php echo htmlspecialchars($author); ?>"><br>
        <label>Genre:</label><br>
        <input type="text" name="genre" value="<?php echo htmlspecialchars($genre); ?>"><br>
        <label>Published Year:</label><br>
        <input type="text" name="published_year" value="<?php echo htmlspecialchars($published_year); ?>"><br><br>
        <input type="submit" name="update" value="Update">
    </form>
    <a href="index.php">Back to book list</a>
</body>
</html>
