<?php

include'./db.php';


if (isset($_POST['update'])) {
    $user_id = $_POST['user_id'];
    $full_name = $_POST['full_name'];
    $phone_number = $_POST['phone_number'];

   
    $query = "UPDATE users SET full_name='$full_name', phone_number='$phone_number' WHERE user_id=$user_id";

    if (mysqli_query($conn, $query)) {
        echo "Record updated successfully";
    } else {
        echo "Error updating record: " . mysqli_error($conn);
    }
}


if (isset($_GET['id'])) {
    $user_id = $_GET['id'];

   
    $query = "SELECT * FROM users WHERE user_id=$user_id";
    $result = mysqli_query($conn, $query);

    if (mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);
        $full_name = $row['full_name'];
        $phone_number = $row['phone_number'];
    } else {
        echo "No user found with the given ID.";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Update User</title>
</head>
<body>
    <h2>Update User</h2>
    <form method="post" action="update_user.php">
        <input type="hidden" name="user_id" value="<?php echo $user_id; ?>">
        <label>Full Name:</label><br>
        <input type="text" name="full_name" value="<?php echo $full_name; ?>"><br>
        <label>Phone Number:</label><br>
        <input type="text" name="phone_number" value="<?php echo $phone_number; ?>"><br><br>
        <input type="submit" name="update" value="Update">
    </form>
    <a href="index.php">Back to user list</a>
</body>
</html>
