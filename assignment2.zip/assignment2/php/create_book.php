<?php
include 'db.php';

$title = $_POST['title'];
$author_name = $_POST['author'];
$genre = $_POST['genre'];
$published_year = $_POST['published_year'];
$image = $_FILES['image']['name'];
$target = "images/" . basename($image);

// Check if author already exists
$author_sql = "SELECT author_id FROM authors WHERE author_name = ?";
$stmt = $conn->prepare($author_sql);
$stmt->bind_param("s", $author_name);
$stmt->execute();
$stmt->store_result();

if ($stmt->num_rows > 0) {
    $stmt->bind_result($author_id);
    $stmt->fetch();
} else {
    // Insert new author
    $insert_author_sql = "INSERT INTO authors (author_name) VALUES (?)";
    $stmt = $conn->prepare($insert_author_sql);
    $stmt->bind_param("s", $author_name);
    $stmt->execute();
    $author_id = $stmt->insert_id;
}

$stmt->close();

// Insert new book
$book_sql = "INSERT INTO books (title, author_id, genre, published_year, image) VALUES (?, ?, ?, ?, ?)";
$stmt = $conn->prepare($book_sql);
$stmt->bind_param("sisss", $title, $author_id, $genre, $published_year, $image);

if ($stmt->execute()) {
    if (move_uploaded_file($_FILES['image']['tmp_name'], $target)) {
        echo "Book added successfully with image";
    } else {
        echo "Book added successfully, but failed to upload image";
    }
} else {
    echo "Error: " . $stmt->error;
}

$stmt->close();
mysqli_close($conn);
header('Location: ../index.php');
?>
