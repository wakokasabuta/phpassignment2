<?php

include 'db.php';


if (isset($_GET['id'])) {
    $user_id = $_GET['id'];

   
    $query = "DELETE FROM users WHERE user_id=$user_id";

    if (mysqli_query($conn, $query)) {
        echo "Record deleted successfully";
    } else {
        echo "Error deleting record: " . mysqli_error($conn);
    }
} else {
    echo "No user ID provided.";
}
?>

<a href="index.php">Back to user list</a>
