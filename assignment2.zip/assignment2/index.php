<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Library</title>
    <link rel="stylesheet" href="../assignment2/css/style.css">
</head>
<body>
    <?php include '../assignment2/header&footer/header.php'; ?>
    <h1>Library Book Management</h1>
    
    <h2>Add New Book</h2>
    <form action="../assignment2/php/create_book.php" method="POST" enctype="multipart/form-data">
        <label for="title">Title:</label>
        <input type="text" id="title" name="title" required>
        
        <label for="author">Author:</label>
        <input type="text" id="author" name="author" required>
        
        <label for="genre">Genre:</label>
        <input type="text" id="genre" name="genre" required>
        
        <label for="published_year">Published Year:</label>
        <input type="number" id="published_year" name="published_year" required>
        
        <label for="image">Book Cover:</label>
        <input type="file" id="image" name="image">
        
        <button type="submit">Add Book</button>
    </form>
    
    <h2>Book List</h2>

    <?php include '../assignment2/php/read_books.php'; ?>
    
    <?php include '../assignment2/header&footer/footer.php'; ?>
</body>
</html>
