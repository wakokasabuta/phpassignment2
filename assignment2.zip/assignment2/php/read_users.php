<?php
include './db.php';

$sql = "SELECT * FROM users";
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {
    echo "<table><tr><th>User ID</th><th>Full Name</th><th>Phone Number</th><th>Actions</th></tr>";
    while($row = mysqli_fetch_assoc($result)) {
        echo "<tr><td>{$row['user_id']}</td><td>{$row['full_name']}</td><td>{$row['phone_number']}</td>
              <td><a href='update_user.php?id={$row['user_id']}'>Edit</a> | <a href='delete_user.php?id={$row['user_id']}'>Delete</a></td></tr>";
    }
    echo "</table>";
} else {
    echo "0 results";
}

mysqli_close($conn);
?>
