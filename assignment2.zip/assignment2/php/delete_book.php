<?php
include './db.php';

// Check if book ID is provided in the URL
if (isset($_GET['id'])) {
    $book_id = $_GET['id'];

    // Delete query
    $query = "DELETE FROM books WHERE book_id=$book_id";

    if (mysqli_query($conn, $query)) {
        echo "Record deleted successfully";
    } else {
        echo "Error deleting record: " . mysqli_error($conn);
    }
} else {
    echo "No book ID provided.";
}

mysqli_close($conn);
?>

<a href="index.php">Back to book list</a>
