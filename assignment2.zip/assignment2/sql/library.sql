CREATE TABLE IF NOT EXISTS `authors` (
    `author_id` INT NOT NULL AUTO_INCREMENT,
    `author_name` VARCHAR(100) NOT NULL,
    PRIMARY KEY (`author_id`)
);

CREATE TABLE IF NOT EXISTS `books` (
    `book_id` INT NOT NULL AUTO_INCREMENT,
    `title` VARCHAR(100) NOT NULL,
    `author_id` INT NOT NULL,
    `genre` VARCHAR(50) NOT NULL,
    `published_year` YEAR NOT NULL,
    `image` VARCHAR(255),
    PRIMARY KEY (`book_id`),
    CONSTRAINT `Books_Author_fk` FOREIGN KEY (`author_id`) REFERENCES `authors`(`author_id`)
);
