<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Library</title>
    <link rel="stylesheet" href="../assignmemnt2/css/style.css">
</head>
<body>
    <footer>
        <p>&copy; 2024 Library Management System</p>
    </footer>
</body>
</html>
