<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "library";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sqlFilePath = __DIR__ . '/../sql/library.sql';
$sql = file_get_contents($sqlFilePath);

if ($conn->multi_query($sql) === TRUE) {
    echo "Database created or exists already.";
} else {
    echo "Error initializing database: " . $conn->error;
}

while ($conn->more_results() && $conn->next_result());

// Do not close the connection here
// mysqli_close($conn);
?>
