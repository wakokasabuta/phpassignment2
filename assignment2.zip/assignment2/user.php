<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>User Management</title>
    <link rel="stylesheet" href="../assignment2/css/style.css">
</head>
<body>
    <?php include '../assignment2/header&footer/header.php'; ?>
    <h1>User Management</h1>
    
    <h2>Add New User</h2>
    <form action="../assignment2/php/create_user.php" method="POST">
        <label for="full_name">Full Name:</label>
        <input type="text" id="full_name" name="full_name" required>
        
        <label for="phone_number">Phone Number:</label>
        <input type="text" id="phone_number" name="phone_number" required>
        
        <button type="submit">Add User</button>
    </form>
    
    <h2>User List</h2>
 
    <?php include '../assignment2/php/read_users.php'; ?>
    
    <?php include '../assignment2/header&footer/footer.php'; ?>
</body>
</html>
